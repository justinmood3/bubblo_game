<template>
  <div class="hud">
    <div class="huditem"><b>Score:</b> {{ score }}</div>
    <div class="huditem"><b>Best:</b> {{ best }}</div>
    <div class="huditem"><b>Lives:</b> <span class="lives">{{ hearts }}</span></div>
    <div class="huditem"><b>Level:</b> {{ level }}</div>
    <div class="huditem status" :class="statusClass">{{ statusLabel }}</div>
  </div>
</template>

<script setup>
import { computed } from "vue";

const props = defineProps({
  score: Number,
  best: Number,
  lives: Number,
  level: Number,
  status: String
});

// Generates heart emojis based on the lives count
const hearts = computed(() => "❤️".repeat(Math.max(0, props.lives || 0)));

// Normalizes status text to uppercase
const statusLabel = computed(() => (props.status || "").toUpperCase());

// FIXED: Added backticks for proper string interpolation
const statusClass = computed(() => `s-${props.status || "idle"}`);
</script>

<style scoped>
.hud {
  display: flex;
  gap: 20px;
  font-family: sans-serif;
  padding: 10px;
  background: #222;
  color: white;
}

.status {
  font-weight: bold;
}

/* Example status classes */
.s-playing { color: #4caf50; }
.s-gameover { color: #ff5252; }
.s-idle { color: #ffeb3b; }
</style>