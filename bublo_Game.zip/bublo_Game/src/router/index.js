import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/HomeView.vue'
import About from '../views/AboutView.vue'
import Game from '../views/GameView.vue'
import NotFound from '../views/NotFoundView.vue'   // <-- Correct variable

const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/about', name: 'About', component: About },
  { path: '/game', name: 'Game', component: Game },
  { path: '/:pathMatch(.*)*', name: 'NotFound', component: NotFound } // fallback 404
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
